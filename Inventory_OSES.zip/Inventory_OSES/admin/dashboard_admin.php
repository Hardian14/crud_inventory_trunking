

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        // connection to database -> tables
        include "../support/connect.php";
        // notifikasi
        include "../support/alerts.php";
        
        // query inventory
        $desktop = mysqli_query($mysqli,"SELECT * FROM inventory where model ='desktop'");
        $ht = mysqli_query($mysqli,"SELECT * FROM inventory where model ='ht'");
    ?>

    ?>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICT Information Management System</title>
    <!-- auto refresh -->
    <meta http-equiv="refresh" content="20">
    <!-- favicon -->
    <link rel="shortcut icon" href="../icon.JPG">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.1/css/all.css" integrity="sha384-xxzQGERXS00kBmZW/6qxqJPyxW3UR0BPsL4c8ILaIWXva5kFi7TxkIIaMiKtqV1Q" crossorigin="anonymous">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
    <!-- css -->
    <style>
        body{
            font-family: 'Raleway', sans-serif;
            font-family: 'Roboto', sans-serif;
            
        }

        .forminv{
          width:60%;
          
        }

        /* @media only screen and (max-width:600px) and (min-width:400px){
          .jumbotron p{
            color:salmon;
          }
        }

        @media only screen and (max-width:800px) and (min-width:601px){
          .jumbotron p{
            color:blue;
          }
        }

        @media only screen and (max-width:1300px) and (min-width:801px){
          .jumbotron p{
            color:green;
            font-size:50px;
          }
        } */

        .footer{
          background-color:#3b3939;
          color:white;
          padding:8px;
        }
    </style>
</head>
<body>

    <!-- Logic Program -->
    
    <!-- End Logic Program -->

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="dashboard_admin.php">Communication Support</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="dashboard_admin.php"><i class="fas fa-home"></i> Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-edit"></i> Input Form
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="create_log.php"><i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="create_inv.php"> <i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="create_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-database"></i> Record Database
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="read_log.php"> <i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="read_inv.php"><i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="read_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
                <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="summary.php"><i class="fas fa-chart-bar"></i> Summary Inventory Trunking</a>
                </div>
          </li>
        </ul>
        <a class="btn btn-primary" href="../support/logout.php" role="button">Logout <i class="fas fa-sign-out-alt"></i></a>
      </div>
    </nav>
          <!-- End Navbar -->
          
          <!-- Content -->
          <br><br><br><br><br><br><br>
          <div class="container">
          <div class="jumbotron">
            <h4 class="display-4">Selamat Datang</h4>
            <h1>ICT - Information Management System </h1>
            
            <hr class="my-4">
            <p style="font-size:24px">Selamat Datang Hardian, Anda Login Sebagai <span style="color:red;font-weight:bold;">Administrator</span>.</p>
            <?php 
                $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
                echo $date->format('l, d F Y H:i:s');
            ?>
            
          </div>
          </div>
          
          
          
          
          <!-- End Content -->
    <br><br><br><br><br><br><br>
    <!-- Footer -->
    

    <div class="footer">
        <marquee>
          Total Desktop : <?php echo mysqli_num_rows($desktop) ." Unit"?> |
          Total HT : <?php echo mysqli_num_rows($ht) ." Unit"?>
        </marquee>
    </div>
    <!-- End Footer -->

    <!-- js & jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>