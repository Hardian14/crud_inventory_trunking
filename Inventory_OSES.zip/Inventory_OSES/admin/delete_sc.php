<?php
include "../support/connect.php";

mysqli_query($mysqli, "DELETE FROM sc WHERE ID = '".$_GET['id']."'");
echo "<script language=javascript>parent.location.href='read_stopcard.php';</script>";
?>