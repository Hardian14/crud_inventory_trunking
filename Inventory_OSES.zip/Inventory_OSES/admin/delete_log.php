<?php
include "../support/connect.php";

mysqli_query($mysqli, "DELETE FROM history WHERE ID = '".$_GET['id']."'");
echo "<script language=javascript>parent.location.href='read_log.php';</script>";
?>