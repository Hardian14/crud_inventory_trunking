

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        // connection to database -> tables
        include "../support/connect.php";
        // notifikasi
        include "../support/alerts.php";
        
        // query inventory
        $desktopPhe     = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRM8668I' and statuss ='PHE OSES'");
        $desktopSpare   = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRM8668I' and statuss ='SPARE LOGISTIC'");
        $desktopBroken  = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRM8668I' and statuss ='BROKEN'");
        $desktopService = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRM8668I' and statuss ='SUPLIER SERVICE'");
        $desktopLost    = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRM8668I' and statuss ='LOST'");
        $desktopUnknown = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRM8668I' and statuss ='UNKNOWN POSITION'");
        $desktopNa      = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRM8668I' and statuss ='N/A'");
        $desktopTotal   = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRM8668I'");
        //$desktopTotal = $desktopPhe + $desktopSpare + $desktopBroken + $desktopService + $desktopLost + $desktopUnknown;
        
        $htPhe     = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRP8668I' and statuss ='PHE OSES'");
        $htSpare   = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRP8668I' and statuss ='SPARE LOGISTIC'");
        $htBroken  = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRP8668I' and statuss ='BROKEN'");
        $htService = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRP8668I' and statuss ='SUPLIER SERVICE'");
        $htLost    = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRP8668I' and statuss ='LOST'");
        $htUnknown = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRP8668I' and statuss ='UNKNOWN POSITION'");
        $htNa      = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRP8668I' and statuss ='N/A'");
        $htTotal   = mysqli_query($mysqli,"SELECT * FROM inventory where type_radio ='XIRP8668I' ");

        $totalPhe       = mysqli_query($mysqli,"SELECT * FROM inventory where statuss ='PHE OSES'");
        $totalSpare     = mysqli_query($mysqli,"SELECT * FROM inventory where statuss ='SPARE LOGISTIC'");
        $totalBroken    = mysqli_query($mysqli,"SELECT * FROM inventory where statuss ='BROKEN'");
        $totalService   = mysqli_query($mysqli,"SELECT * FROM inventory where statuss ='SUPLIER SERVICE'");
        $totalLost      = mysqli_query($mysqli,"SELECT * FROM inventory where statuss ='LOST'");
        $totalUnknown   = mysqli_query($mysqli,"SELECT * FROM inventory where statuss ='UNKNOWN POSITION'");
        $totals         = mysqli_query($mysqli,"SELECT * FROM inventory");

        // query department
        $htDrilling = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='drilling' and statuss='PHE OSES'");
        $htHrsss    = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='hrsss' and statuss='PHE OSES'");
        $htIct      = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='ict' and statuss='PHE OSES'");
        $htLimo     = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='lifting & marine operation' and statuss='PHE OSES'");
        $htNfdPgf   = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='nfd & pgf' and statuss='PHE OSES'");
        $htCbu      = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='production cbu' and statuss='PHE OSES'");
        $htNbu      = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='production nbu' and statuss='PHE OSES'");
        $htSbu      = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='production sbu' and statuss='PHE OSES'");
        $htQhse     = mysqli_query($mysqli,"SELECT * FROM inventory where model='ht' and department='qhse' and statuss='PHE OSES'");

        $desktopDrilling = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='drilling' and statuss='PHE OSES'");
        $desktopHrsss    = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='hrsss' and statuss='PHE OSES'");
        $desktopIct      = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='ict' and statuss='PHE OSES'");
        $desktopLimo     = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='lifting & marine operation' and statuss='PHE OSES'");
        $desktopNfdPgf   = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='nfd & pgf' and statuss='PHE OSES'");
        $desktopCbu      = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='production cbu' and statuss='PHE OSES'");
        $desktopNbu      = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='production nbu' and statuss='PHE OSES'");
        $desktopSbu      = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='production sbu' and statuss='PHE OSES'");
        $desktopQhse     = mysqli_query($mysqli,"SELECT * FROM inventory where model='desktop' and department='qhse' and statuss='PHE OSES'");

        $trunkingDrilling = mysqli_query($mysqli,"SELECT * FROM inventory where department='drilling' and statuss='PHE OSES'");
        $trunkingHrsss    = mysqli_query($mysqli,"SELECT * FROM inventory where department='hrsss' and statuss='PHE OSES'");
        $trunkingIct      = mysqli_query($mysqli,"SELECT * FROM inventory where department='ict' and statuss='PHE OSES'");
        $trunkingLimo     = mysqli_query($mysqli,"SELECT * FROM inventory where department='lifting & marine operation' and statuss='PHE OSES'");
        $trunkingNfdPgf   = mysqli_query($mysqli,"SELECT * FROM inventory where department='nfd & pgf' and statuss='PHE OSES'");
        $trunkingCbu      = mysqli_query($mysqli,"SELECT * FROM inventory where department='production cbu' and statuss='PHE OSES'");
        $trunkingNbu      = mysqli_query($mysqli,"SELECT * FROM inventory where department='production nbu' and statuss='PHE OSES'");
        $trunkingSbu      = mysqli_query($mysqli,"SELECT * FROM inventory where department='production sbu' and statuss='PHE OSES'");
        $trunkingQhse     = mysqli_query($mysqli,"SELECT * FROM inventory where department='qhse' and statuss='PHE OSES'");
        
      
    ?>



    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICT Information Management System</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="../icon.JPG">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.1/css/all.css" integrity="sha384-xxzQGERXS00kBmZW/6qxqJPyxW3UR0BPsL4c8ILaIWXva5kFi7TxkIIaMiKtqV1Q" crossorigin="anonymous">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
    <!-- css -->
    <style>
        body{
            font-family: 'Raleway', sans-serif;
            font-family: 'Roboto', sans-serif;
            
        }

        table{
            text-align:center;
        }

        .tabledept{
          width:70%;
        }
        
    </style>
</head>
<body>

    <!-- Logic Program -->
    
    <!-- End Logic Program -->

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="dashboard_admin.php">Communication Support</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="dashboard_admin.php"><i class="fas fa-home"></i> Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-edit"></i> Input Form
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="create_log.php"><i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="create_inv.php"> <i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="create_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-database"></i> Record Database
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="read_log.php"> <i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="read_inv.php"><i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="read_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
                <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="summary.php"><i class="fas fa-chart-bar"></i> Summary Inventory Trunking</a>
                </div>
          </li>
        </ul>
        <a class="btn btn-primary" href="../support/logout.php" role="button">Logout <i class="fas fa-sign-out-alt"></i></a>
      </div>
    </nav>
          <!-- End Navbar -->
          
          <!-- Content -->
          <br><br><br><br><br>
          
              <div class="container">
                <h2>Summary Inventory Trunking</h2>
                <hr>
                <h4>BASED ON LOGISTIC</h4>
                  <table class="table table-bordered table-hover" >
                    <thead>
                      <tr>
                        <th rowspan="2" style="padding-bottom:35px;">NO.</th>
                        <th rowspan="2" style="padding-bottom:35px;">TYPE</th>
                        <th rowspan="2" style="padding-bottom:35px;">MODEL</th>
                        <th colspan="6" style="text-align:center;">STATUS</th>
                        <th rowspan="2" style="padding-bottom:35px;">TOTAL</th>
                      </tr>
                      <tr>
                        <th>PHE OSES</th>
                        <th>SPARE LOGISTIC</th>
                        <th>BROKEN</th>
                        <th>SUPPLIER SERVICE</th>
                        <th>LOST</th>
                        <th>UNKNOWN LOCATION</th>
                      </tr>
                    </thead>
                    <tbody>
                        <tr>
                          <td>1.</td>
                          <td>XiR P8668i</td>
                          <td>HT</td>
                          <td><?php echo mysqli_num_rows($htPhe)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($htSpare)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($htBroken)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($htService)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($htLost)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($htUnknown)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($htTotal)?></td> <!--isi dengan query -->
                        </tr>
                        <tr>
                          <td>2.</td>
                          <td>XiR M8668i</td>
                          <td>DESKTOP</td>
                          <td><?php echo mysqli_num_rows($desktopPhe)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($desktopSpare)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($desktopBroken)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($desktopService)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($desktopLost)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($desktopUnknown)?></td> <!--isi dengan query -->
                          <td><?php echo mysqli_num_rows($desktopTotal)?></td> <!--isi dengan query -->
                        </tr>
                        <tr>
                          <td colspan="3" style="text-align:center;">TOTAL</td>
                          <td><?php echo mysqli_num_rows($totalPhe)?></td>
                          <td><?php echo mysqli_num_rows($totalSpare)?></td>
                          <td><?php echo mysqli_num_rows($totalBroken)?></td>
                          <td><?php echo mysqli_num_rows($totalService)?></td>
                          <td><?php echo mysqli_num_rows($totalLost)?></td>
                          <td><?php echo mysqli_num_rows($totalUnknown)?></td>
                          <td><?php echo mysqli_num_rows($totals)?></td>
                        </tr>
                    </tbody>
                  </table>
                  <br>
                  <hr>
                  <h4>ACTIVE SUBSCRIBERS BASED ON DEPARTMENT</h4>
                  <div class="tabledept">
                  <table class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>NO.</th>
                        <th>DEPARTMENT</th>
                        <th>HT</th>
                        <th>DESKTOP</th>
                        <th>TOTAL</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>1.</td>
                        <td>DRILLING</td>
                        <td><?php echo mysqli_num_rows($htDrilling) ?></td>
                        <td><?php echo mysqli_num_rows($desktopDrilling) ?></td>
                        <td><?php echo mysqli_num_rows($trunkingDrilling) ?></td>
                      </tr>
                      <tr>
                        <td>2.</td>
                        <td>HRSSS</td>
                        <td><?php echo mysqli_num_rows($htHrsss) ?></td>
                        <td><?php echo mysqli_num_rows($desktopHrsss) ?></td>
                        <td><?php echo mysqli_num_rows($trunkingHrsss) ?></td>
                      </tr>
                      <tr>
                        <td>3.</td>
                        <td>ICT</td>
                        <td><?php echo mysqli_num_rows($htIct) ?></td>
                        <td><?php echo mysqli_num_rows($desktopIct) ?></td>
                        <td><?php echo mysqli_num_rows($trunkingIct) ?></td>
                      </tr>
                      <tr>
                        <td>4.</td>
                        <td>LIFTTING & MARINE OPERATION</td>
                        <td><?php echo mysqli_num_rows($htLimo) ?></td>
                        <td><?php echo mysqli_num_rows($desktopLimo) ?></td>
                        <td><?php echo mysqli_num_rows($trunkingLimo) ?></td>
                      </tr>
                      <tr>
                        <td>5.</td>
                        <td>NFD & PGF</td>
                        <td><?php echo mysqli_num_rows($htNfdPgf)?></td>
                        <td><?php echo mysqli_num_rows($desktopNfdPgf)?></td>
                        <td><?php echo mysqli_num_rows($trunkingNfdPgf)?></td>
                      </tr>
                      <tr>
                        <td>5.</td>
                        <td>PRODUCTION CBU</td>
                        <td><?php echo mysqli_num_rows($htCbu) ?></td>
                        <td><?php echo mysqli_num_rows($desktopCbu) ?></td>
                        <td><?php echo mysqli_num_rows($trunkingCbu) ?></td>
                      </tr>
                      <tr>
                        <td>6.</td>
                        <td>PRODUCTION NBU</td>
                        <td><?php echo mysqli_num_rows($htNbu) ?></td>
                        <td><?php echo mysqli_num_rows($desktopNbu) ?></td>
                        <td><?php echo mysqli_num_rows($trunkingNbu) ?></td>
                      </tr>
                      <tr>
                        <td>7.</td>
                        <td>PRODUCTION SBU</td>
                        <td><?php echo mysqli_num_rows($htSbu) ?></td>
                        <td><?php echo mysqli_num_rows($desktopSbu) ?></td>
                        <td><?php echo mysqli_num_rows($trunkingSbu) ?></td>
                      </tr>
                      <tr>
                        <td>8.</td>
                        <td>QHSE</td>
                        <td><?php echo mysqli_num_rows($htQhse) ?></td>
                        <td><?php echo mysqli_num_rows($desktopQhse) ?></td>
                        <td><?php echo mysqli_num_rows($trunkingQhse) ?></td>
                      </tr>
                    </tbody>
                  </table>
                  </div>
                  
              </div>
          
          
          
          
          <!-- End Content -->
    <br><br><br><br><br><br><br>
    <!-- Footer -->
    <!-- End Footer -->

    <!-- js & jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>