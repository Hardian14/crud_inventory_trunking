<!DOCTYPE html>
<html lang="en">
<head>
<?php
        // connection to database -> tables
        include "../support/connect.php";
        // notifikasi
        include "../support/alerts.php";

    ?>

    <?php
        $query = mysqli_query($mysqli,"SELECT 
            id,
            serial_number, 
            id_radio, 
            type_radio, 
            model, 
            department, 
            bu,
            locations,
            user,
            alias,
            statuss
          FROM inventory ORDER BY serial_number ASC");
    ?>

      <script type="text/javascript">
        window.apex_search = {};
        apex_search.init = function (){
          this.rows = document.getElementById('data').getElementsByTagName('TR');
          this.rows_length = apex_search.rows.length;
          this.rows_text =  [];
          for (var i=0;i<apex_search.rows_length;i++){
                this.rows_text[i] = (apex_search.rows[i].innerText)?apex_search.rows[i].innerText.toUpperCase():apex_search.rows[i].textContent.toUpperCase();
          }
          this.time = false;
        }
        apex_search.lsearch = function(){
          this.term = document.getElementById('S').value.toUpperCase();
          for(var i=0,row;row = this.rows[i],row_text = this.rows_text[i];i++){
            row.style.display = ((row_text.indexOf(this.term) != -1) || this.term  === '')?'':'none';
          }
          this.time = false;
        }
        apex_search.search = function(e){
            var keycode;
            if(window.event){keycode = window.event.keyCode;}
            else if (e){keycode = e.which;}
            else {return false;}
            if(keycode == 13) { apex_search.lsearch(); } else { return false; }
        }
      </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICT Information Management SystemS</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="../icon.JPG">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.1/css/all.css" integrity="sha384-xxzQGERXS00kBmZW/6qxqJPyxW3UR0BPsL4c8ILaIWXva5kFi7TxkIIaMiKtqV1Q" crossorigin="anonymous">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&family=Roboto:wght@300;400&display=swap" rel="stylesheet">

    <style>
       body{
            font-family: 'Raleway', sans-serif;
            font-family: 'Roboto', sans-serif;
        }

        .search{
          width:35%;
        }

        @media only screen and (min-width:300px) and (max-width:600px){
          .search{
            width:90%;
          }
        }

        @media only screen and (min-width:600px) and (max-width:900px){
          .search{
            width:90%;
          }
        }

        @media only screen and (min-width:900px) and (max-width:1100px){
          .search{
            width:50%;
          }
        }
    </style>
</head>
<body onload="apex_search.init();">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="dashboard_admin.php">Communication Support</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="dashboard_admin.php"><i class="fas fa-home"></i> Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-edit"></i> Input Form
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="create_log.php"><i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="create_inv.php"> <i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="create_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-database"></i> Record Database
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="read_log.php"> <i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="read_inv.php"><i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="read_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
                <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="summary.php"><i class="fas fa-chart-bar"></i> Summary Inventory Trunking</a>
                </div>
          </li>
        </ul>
        <a class="btn btn-primary" href="../support/logout.php" role="button">Logout <i class="fas fa-sign-out-alt"></i></a>
      </div>
    </nav>
    <!-- End Navbar -->

        <br><br><br><br>
    <!-- CONTENT -->
    <div class="container">
    

    
        <!-- 2. Data -->
        
                <h2>Data Inventory Trunking</h2>
                <p><b><h4>Total Record : <?php echo mysqli_num_rows($query) ." Data"?></h4></b></p>
                <div class="search">
                    <div class="input-group ">
                        <input type="text" class="form-control" placeholder="Input keyword" aria-label="Input keyword" aria-describedby="button-addon2" maxlength="1000" value="" id="S" onkeyup="apex_search.search(event);" />
                        <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="button" id="button-addon2" onclick="apex_search.lsearch();"/><i class="fas fa-search"></i> SEARCH</button>
                        </div>
                    </div>
                </div>
                
                <br>
                <div class="export">
                  <a href="export_inv.php" class="btn btn-success"> Export to Excel</a>
                </div>
                <br>
                <table class="table table-hover table-bordered table-striped table-dark" width="100">
                    <thead>
                      <tr>
                        <th><center>NO</center></th>
                        <th>SERIAL NUMBER</th>
                        <th >ID RADIO</th>
                        <th >TYPE RADIO</th>
                        <th >MODEL</th>
                        <th >DEPARTMENT</th>
                        <th >BU</th>
                        <th >LOCATION</th>
                        <th >USER</th>
                        <th >ALIAS</th>
                        <th >STATUS</th>
                        <th width="8%" >ACTION</th>
                      </tr>
                    </thead>
                    <tbody id="data">
                      <?php $no=1; while ($row = mysqli_fetch_array($query)) { ?>
                      <tr>
                        <td align="center" ><?php echo $no; ?></td>
                        <td><?php echo $row['serial_number']; 	?></td>
                        <td><?php echo $row['id_radio']; 		?></td>
                        <td><?php echo $row['type_radio']; 		?></td>
                        <td><?php echo $row['model']; 			?></td>
                        <td><?php echo $row['department']; 		?></td>
                        <td><?php echo $row['bu']; 				?></td>
                        <td><?php echo $row['locations']; 		?></td>
                        <td><?php echo $row['user']; 			?></td>
                        <td><?php echo $row['alias']; 			?></td>
                        <td><?php echo $row['statuss']; 		?></td>
                        <td align="center">
                          <a href="update_inv.php?id=<?php echo $row['id']; ?>"><i class="fas fa-edit"></i></a> 
                            |
                          <a href="delete_inv.php?id=<?php echo $row['id']; ?>" onclick ="if (!confirm('Are You Sure Delete This Data ?')) return false;"><i class="fas fa-trash-alt"></i></a>
                        </td>
                      </tr>
                      <?php $no++; } ?>	
                    </tbody>
                  </table>

           
    </div> <!-- penutup class container -->  

    <!-- END CONTENT -->
    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>