

<!DOCTYPE html>
<html lang="en">
<head>


    <?php
        // connection to database -> tables
        include "../support/connect.php";
        // notifikasi
        include "../support/alerts.php";

    ?>

    <?php
      $query = mysqli_query ($mysqli,"SELECT 
      id, 
      nama, 
      tgl, 
      minggu, 
      kondisi, 
      kategori, 
      loc, 
      des 
      FROM sc ORDER BY tgl DESC");
    ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICT Information Management System</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="../icon.JPG">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.1/css/all.css" integrity="sha384-xxzQGERXS00kBmZW/6qxqJPyxW3UR0BPsL4c8ILaIWXva5kFi7TxkIIaMiKtqV1Q" crossorigin="anonymous">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
    <!-- css -->
    <style>
        body{
            font-family: 'Raleway', sans-serif;
            font-family: 'Roboto', sans-serif;
        }

        table{
          position: relative;
          text-align: center;
          font-size:15px;
          width:200px;
        }
        
        .kotaktabel{
          width:95%;
        }

        @media only screen and (min-width:300px) and (max-width:600px){
          .sidebar{
            width:95%;
            margin:auto;

          }

          .content{
            width:95%;
            margin:auto;
            padding-top:30px;
          }
        }

    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="dashboard_admin.php">Communication Support</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="dashboard_admin.php"><i class="fas fa-home"></i> Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-edit"></i> Input Form
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="create_log.php"><i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="create_inv.php"> <i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="create_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-database"></i> Record Database
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="read_log.php"> <i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="read_inv.php"><i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="read_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
                <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="summary.php"><i class="fas fa-chart-bar"></i> Summary Inventory Trunking</a>
                </div>
          </li>
        </ul>
        <a class="btn btn-primary" href="../support/logout.php" role="button">Logout <i class="fas fa-sign-out-alt"></i></a>
      </div>
    </nav>
          <!-- End Navbar -->
          
          <!-- Content -->

          <br><br><br>
          <div class="row">
            <!-- Sidebar -->
            <div class="col-sm-3 offset-sm-1" style=" text-align:justify;">
              <div class="sidebar">
                <div class="accordion" id="accordionExample">

                  <!-- 1st card  -->
                  <div class="card">
                    <div class="card-header" id="headingOne">
                      <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        Next Development
                        </button>
                      </h2>
                    </div>
                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                      <div class="card-body">
                        <iframe width="350" height="300" src="https://www.youtube.com/embed/eIb0o2Ni8s0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                      </div>
                    </div>
                  </div>

                  <!-- 2nd card -->
                  <div class="card">
                    <div class="card-header" id="headingTwo">
                      <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        Next Development
                        </button>
                      </h2>
                    </div>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                      <div class="card-body">
                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                      </div>
                    </div>
                  </div>

                  <!-- 3rd card -->
                  <div class="card">
                    <div class="card-header" id="headingThree">
                      <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        Next Development
                        </button>
                      </h2>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                      <div class="card-body">
                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                      </div>
                    </div>
                  </div>

                </div> <!-- penutup accordion -->
              </div> <!-- penutup class sidebar -->
            </div> <!-- penutup class col-sm-3 offset-sm-1 / kolom pertama -->
            <!-- Data -->
              <div class="col-sm-8">
                <div class="content">
                <h2>Stop Card Records</h2>
                <br>
                <p><h4>Total Record : <?php echo mysqli_num_rows($query) ." Data"?></h4></p>
                <div class="kotaktabel">
                  <table class="table table-hover table-bordered table-striped table-dark">
                    <thead>
                      <tr>
                        <th width="5%"><center>NO</center></th>
                        <th>NAMA</th>
                        <th>TANGGAL</th>
                        <th>MINGGU</th>
                        <th>KONDISI</th>
                        <th>KATEGORI</th>
                        <th>LOKASI</th>
                        <th>DESKRIPSI</th>
                        <th width="15%"><center>ACTION</center></th>
                      </tr>
                    </thead>
                    <tbody id="data">
                      <?php $no=1; while ($row = mysqli_fetch_array($query)) { ?>
                      <tr>
                        <td align="center"><?php echo $no; ?></td>
                        <td><?php echo $row['nama']; ?></td>
                        <td><?php echo $row['tgl']; ?></td>
                        <td><?php echo $row['minggu']; ?></td>
                        <td><?php echo $row['kondisi']; ?></td>
                        <td><?php echo $row['kategori']; ?></td>
                        <td><?php echo $row['loc']; ?></td>
                        <td style="text-align: justify;"><?php echo $row['des']; ?></td>
                        <td align="center">
                        <a href="update_stopcard.php?id=<?php echo $row['id']; ?>"><i class="fas fa-edit"></i></a> 
                        | 
                        <a href="delete_sc.php?id=<?php echo $row['id']; ?>" onclick ="if (!confirm('Are You Sure Delete This Data?')) return false;"><i class="fas fa-trash-alt"></i</a>
                        </td>
                      </tr>
                      <?php $no++; } ?>	
                    </tbody>
                  </table>
                </div> <!-- penutup class kotaktabel -->  
                </div> <!-- penutup class content -->
              </div> <!-- penutup class col-sm-8 / kolom kedua -->
          </div> <!-- penutup class row -->
          
          
          <!-- End Content -->

    <!-- Footer -->
    <!-- End Footer -->

    <!-- js & jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>