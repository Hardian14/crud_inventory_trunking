<?php
include "../support/connect.php";

mysqli_query($mysqli, "DELETE FROM inventory WHERE ID = '".$_GET['id']."'");
echo "<script language=javascript>parent.location.href='read_inv.php';</script>";
?>