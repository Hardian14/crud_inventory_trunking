

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        // connection to database -> tables
        include "../support/connect.php";
        // notifikasi
        include "../support/alerts.php";

    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICT Information Management System</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="../icon.JPG">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.1/css/all.css" integrity="sha384-xxzQGERXS00kBmZW/6qxqJPyxW3UR0BPsL4c8ILaIWXva5kFi7TxkIIaMiKtqV1Q" crossorigin="anonymous">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
    <!-- css -->
    <style>
        body{
            font-family: 'Raleway', sans-serif;
            font-family: 'Roboto', sans-serif;
        }

        .data{
          width:80%;
          margin:auto;
        }

        /* @media only screen and (max-width:600px) and (min-width:300px){
            .sidebar{
              width:95%;
              margin:auto;
              
            }

            .data{
              padding-top:30px;
              width:95%;
              margin:auto;
            }
        } */

       

    </style>
</head>
  <body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="dashboard_admin.php">Communication Support</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="dashboard_admin.php"><i class="fas fa-home"></i> Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-edit"></i> Input Form
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="create_log.php"><i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="create_inv.php"> <i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="create_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-database"></i> Record Database
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="read_log.php"> <i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="read_inv.php"><i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="read_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
                <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="summary.php"><i class="fas fa-chart-bar"></i> Summary Inventory Trunking</a>
                </div>
          </li>
        </ul>
        <a class="btn btn-primary" href="../support/logout.php" role="button">Logout <i class="fas fa-sign-out-alt"></i></a>
      </div>
    </nav>
    <!-- End Navbar -->

    <br><br><br><br><br>      
    <div class="container">
            <!-- Content -->
            <div class="data ">
            <h4><b>Input Form Trunking For Subscribers </b></h4>
            <form id="form_input" method="POST" action="create_inv.php">	
              <?php  
                if(isset($_POST['save']))
                  {
                    mysqli_query($mysqli, "INSERT INTO inventory (
                      serial_number, 
                      id_radio, 
                      type_radio, 
                      model, 
                      department, 
                      bu,
                      locations,
                      user,
                      alias,
                      statuss
                    ) VALUES (
                        '".$_POST['serial_number']."',
                        '".$_POST['id_radio']."',
                            '".$_POST['type_radio']."',
                            '".$_POST['model']."',
                            '".$_POST['department']."',
                            '".$_POST['bu']."',
                            '".$_POST['locations']."',
                            '".$_POST['user']."',
                            '".$_POST['alias']."',
                            '".$_POST['statuss']."'			
                              )");
                          writeMsg('save.sukses');
                  }
              ?>
              
              <!-- SERIAL NUMBER -->
              <br>
              <div class="form-group">
                <label class="control-label" for="SN"><b>SERIAL NUMBER</b></label>
                <input type="text" class="form-control" name="serial_number" id="serial_number" required>
              </div>

              <!-- ID RADIO -->
              <div class="form-group">
                <label class="control-label" for="ID_R"><b>ID RADIO </b></label>
                <input type="text" class="form-control" placeholder="id radio 4 digits number.." name="id_radio" id="id_radio" required>
              </div>

              <!-- TYPE RADIO -->
              <div class="form-group">
                <label class="control-label" for="TYPE_R"><b>TYPE RADIO</b></label><br>
                <label><input type="radio" name="type_radio" value="XIRP8668I"> XIRP8668I</label>
                <label><input type="radio" name="type_radio" value="XIRM8668I"> XIRM8668I</label>
              </div>

              <!-- MODEL -->
              <div class="form-group">
                <label class="control-label" for="MOD"><b>MODEL</b></label> <br>
                <label><input type="radio" name="model" value="HT"> HT</label>
                <label><input type="radio" name="model" value="DESKTOP"> DESKTOP</label>
              </div>

              <!-- DEPARTMENT -->
              <div class="form-group">
                <label class="control-label" for="department"><b>DEPARTMENT</b></label>
                <select class="form-control" name="department" id="department" >
                  <option>--- Please Select ---</option>
                  <option value="DRILLING"					>DRILLING						</option>
                  <option value="HRSSS"						>HRSSS							</option>
                  <option value="ICT"							>ICT							</option>
                  <option value="LIFTTING & MARINE OPERATION"	>LIFTTING & MARINE OPERATION	</option>
                  <option value="NFD & PGF"					>NFD & PGF						</option>
                  <option value="PRODUCTION CBU"				>PRODUCTION CBU					</option>
                  <option value="PRODUCTION NBU"				>PRODUCTION NBU					</option>
                  <option value="PRODUCTION SBU"				>PRODUCTION SBU					</option>
                  <option value="QHSE"						>QHSE							</option>
                  <option value="N/A"							>N/A							</option>
                </select>
              </div>

              <!-- BU -->
              <div class="form-group">
                <label class="control-label" for="bu"><b>BUSINESS UNIT</b></label>
                <select class="form-control" name="bu" id="bu" >
                  <option>--- Please Select ---</option>
                  <option value="BARGE"					>BARGE			</option>
                  <option value="BOAT"					>BOAT			</option>
                  <option value="CENTRAL"					>CENTRAL		</option>
                  <option value="CIPALA"					>CIPALA	</option>
                  <option value="GMS"						>GMS			</option>	
                  <option value="NORTH"					>NORTH			</option>
                  <option value="OFFICE ISEB"				>OFFICE ISEB	</option>
                  <option value="OFFICE JASNIKOM"			>OFFICE JASNIKOM</option>
                        <option value="RIG"						>RIG			</option>
                        <option value="SOUTH"					>SOUTH			</option>
                        <option value="WAREHOUSE KJ4"			>WAREHOUSE KJ4	</option>
                        <option value="N/A"						>N/A			</option>
                      </select>
                    </div>

                    <!-- LOCATIONS -->
                    <!-- disesuaikan lebih detil untuk seluruh nama platform -->
                    <div class="form-group">
                      <label class="control-label" for="locations"><b>LOCATION</b></label>
                      <select class="form-control" name="locations" id="locations" >
                        <option>--- Please Select ---</option>
                        
                        <option	value="AIDA"				>AIDA</option>
                        <option	value="ASTI A"				>ASTI A</option>
                        <option	value="ATTI"				>ATTI</option>
                        <option	value="BANUWATI"			>BANUWATI</option>
                        <option	value="BANUWATI A"			>BANUWATI A</option>
                        <option	value="BANUWATI K"			>BANUWATI K</option>
                        <option	value="BAYU CAKRAWALA"		>BAYU CAKRAWALA </option>
                        <option	value="CILEGON GMS"			>CILEGON GMS</option>
                        <option	value="CILEGON PCI"			>CILEGON PCI</option>
                        <option	value="CINTA A"				>CINTA A </option>
                        <option	value="CINTA B"				>CINTA B </option>
                        <option	value="CINTA C"				>CINTA C </option>
                        <option	value="CINTA D"				>CINTA D </option>
                        <option	value="CINTA E"				>CINTA E </option>
                        <option	value="CINTA F"				>CINTA F </option>
                        <option	value="CINTA G"				>CINTA G </option>
                        <option	value="CINTA H"				>CINTA H </option>
                        <option	value="CIPALA"				>CIPALA</option>
                        <option	value="CNOOC 114"			>CNOOC 114 </option>
                        <option	value="COSL 221"			>COSL 221 </option>
                        <option	value="COSL 222"			>COSL 222 </option>
                        <option	value="COSL 223"			>COSL 223 </option>
                        <option	value="COSL 225"			>COSL 225 </option>
                        <option	value="CREST RUBY"			>CREST RUBY</option>
                        <option	value="ERA MERAH PUTIH"		>ERA MERAH PUTIH</option>
                        <option	value="ERMA"				>ERMA </option>
                        <option	value="FARIDA A"			>FARIDA A </option>
                        <option	value="FARIDA B"			>FARIDA B </option>
                        <option	value="FARIDA C"			>FARIDA C </option>
                        <option	value="FEDERAL II"			>FEDERAL II </option>
                        <option	value="GIAT JAYA"			>GIAT JAYA </option>
                        <option	value="GITA A"				>GITA A </option>
                        <option	value="HYSY 902"			>HYSY 902 </option>
                        <option	value="INA PERMATA 1"		>INA PERMATA 1</option>
                        <option	value="INA PERMATA 2"		>INA PERMATA 2</option>
                        <option	value="INDRI A"				>INDRI A </option>
                        <option	value="INTAN A"				>INTAN A </option>
                        <option	value="INTAN AC"			>INTAN AC </option>
                        <option	value="INTAN B"				>INTAN B </option>
                        <option	value="INTAN BPC"			>INTAN BPC</option>
                        <option	value="JASNIKOM OFFICE"		>JASNIKOM OFFICE</option>
                        <option	value="JENNY"				>JENNY</option>
                        <option	value="KARMILA A"			>KARMILA A </option>
                        <option	value="KARTINI A"			>KARTINI A</option>
                        <option	value="KITTY A"				>KITTY A </option>
                        <option	value="KRISNA ALPHA"		>KRISNA ALPHA </option>
                        <option	value="KRISNA B"			>KRISNA B  </option>
                        <option	value="KRISNA C"			>KRISNA C </option>
                        <option	value="KRISNA D"			>KRISNA D </option>
                        <option	value="KRISNA E"			>KRISNA E  </option>
                        <option	value="KRISNA P"			>KRISNA P </option>
                        <option	value="LCT PERDANA HARAPAN IX"				>LCT PERDANA HARAPAN IX</option>
                        <option	value="LITA"				>LITA </option>
                        <option	value="LOGINDO BRAVEHEART"	>LOGINDO BRAVEHEART </option>
                        <option	value="LOGINDO RALIANCE"	>LOGINDO RALIANCE </option>
                        <option	value="LYDIA"				>LYDIA </option>
                        <option	value="MAGELANG"			>MAGELANG </option>
                        <option	value="MEGAWATI 17"			>MEGAWATI 17 </option>
                        <option	value="MEGAWATI 2"			>MEGAWATI 2</option>
                        <option	value="MILA A"				>MILA A </option>
                        <option	value="MITRA ANUGRAH 32"	>MITRA ANUGRAH 32</option>
                        <option	value="MITRA ANUGRAH 35"	>MITRA ANUGRAH 35</option>
                        <option	value="NEIA A"				>NEIA A </option>
                        <option	value="NEIA AC"				>NEIA AC </option>
                        <option	value="NMS ACCELERATE"		>NMS ACCELERATE</option>
                        <option	value="NMS ACCOMPLISH"		>NMS ACCOMPLISH</option>
                        <option	value="NMS ACHIEVE"			>NMS ACHIEVE</option>
                        <option	value="NMS BRILIANCE"		>NMS BRILIANCE</option>
                        <option	value="NORA A"				>NORA A </option>
                        <option	value="NORTH WANDA ALFA"	>NORTH WANDA ALFA </option>
                        <option	value="NORTH WANDA B"		>NORTH WANDA B </option>
                        <option	value="OFFICE ISEB"			>OFFICE ISEB</option>
                        <option	value="PABELOKAN"			>PABELOKAN </option>
                        <option	value="PAN MARINE 6"		>PAN MARINE 6</option>
                        <option	value="PAN MARINE 8"		>PAN MARINE 8</option>
                        <option	value="PAN MARINE 18"		>PAN MARINE 18</option>
                        <option	value="PAN MARINE 19"		>PAN MARINE 19</option>
                        <option	value="PATRA MARINE"		>PATRA MARINE </option>
                        <option	value="PET. EXCELSIOR"		>PET. EXCELSIOR </option>
                        <option	value="PET. SUPERIOR"		>PET. SUPERIOR </option>
                        <option	value="PRISAI"				>PRISAI </option>
                        <option	value="RAMA A"				>RAMA A </option>
                        <option	value="RAMA B"				>RAMA B </option>
                        <option	value="RAMA C"				>RAMA C </option>
                        <option	value="RAMA D"				>RAMA D </option>
                        <option	value="RAMA E"				>RAMA E </option>
                        <option	value="RAMA F"				>RAMA F </option>
                        <option	value="RAMA G"				>RAMA G </option>
                        <option	value="RAMA H"				>RAMA H </option>
                        <option	value="RAMA I"				>RAMA I </option>
                        <option	value="RAMA P"				>RAMA P </option>
                        <option	value="RIG HL 6"			>RIG HL 6 </option>
                        <option	value="RIG LISA"			>RIG LISA </option>
                        <option	value="SALATIGA"			>SALATIGA</option>
                        <option	value="SELATAN A"			>SELATAN A </option>
                        <option	value="SOUTH WANDA A"		>SOUTH WANDA A </option>
                        <option	value="SOUTH ZELDA"			>SOUTH ZELDA </option>
                        <option	value="STAR ONIX"			>STAR ONIX </option>
                        <option	value="SUNDARI A"			>SUNDARI A </option>
                        <option	value="SUNDARI B"			>SUNDARI B  </option>
                        <option	value="SURATMI"				>SURATMI </option>
                        <option	value="SURF MANDIRI"		>SURF MANDIRI</option>
                        <option	value="SWIBER RUBY"			>SWIBER RUBY </option>
                        <option	value="THERESIA"			>THERESIA </option>
                        <option	value="TITI A PCR"			>TITI A PCR  </option>
                        <option	value="TRANSKO BALIHE"		>TRANSKO BALIHE</option>
                        <option	value="TRANSKO CELEBES"		>TRANSKO CELEBES</option>
                        <option	value="TRITON JAWARA"		>TRITON JAWARA</option>
                        <option	value="VITA"				>VITA </option>
                        <option	value="WANDA A"				>WANDA A </option>
                        <option	value="WIDURI A"			>WIDURI A </option>
                        <option	value="WIDURI B"			>WIDURI B </option>
                        <option	value="WIDURI C"			>WIDURI C </option>
                        <option	value="WIDURI D"			>WIDURI D </option>
                        <option	value="WIDURI DC"			>WIDURI DC </option>
                        <option	value="WIDURI E"			>WIDURI E </option>
                        <option	value="WIDURI F"			>WIDURI F </option>
                        <option	value="WIDURI G"			>WIDURI G </option>
                        <option	value="WIDURI H"			>WIDURI H </option>
                        <option	value="WIDURI PROCESS"		>WIDURI PROCESS</option>
                        <option	value="WINDRI"				>WINDRI </option>
                        <option	value="YANI A"				>YANI A </option>
                        <option	value="YVONE ALPHA"			>YVONE ALPHA </option>
                        <option	value="YVONE B"				>YVONE B  </option>
                        <option	value="ZELD P"				>ZELD P </option>
                        <option	value="ZELDA B"				>ZELDA B  </option>
                        <option	value="ZELDA C"				>ZELDA C  </option>
                        <option	value="ZELDA D"				>ZELDA D </option>
                        <option	value="ZELDA E"				>ZELDA E </option>
                        <option	value="ZELDA F"				>ZELDA F </option>
                        <option	value="ZELDA PC"			>ZELDA PC</option>
                        <option value="N/A"					>N/A	</option>
                      </select>
                    </div>

                    <!-- USER -->
                    <div class="form-group">
                      <label class="control-label" for="user"><b>USER</b></label>
                      <input type="text" class="form-control" name="user" id="user">
                    </div>

                    <!-- ALIAS -->
                    <div class="form-group">
                      <label class="control-label" for="alias"><b>ALIAS</b></label>
                      <input type="text" class="form-control" name="alias" id="alias" >
                    </div>

                    <!-- STATUS -->
                    <div class="form-group">
                      <label class="control-label" for="statuss"><b>STATUS</b></label>
                      <select class="form-control" name="statuss" id="statuss" >
                        <option>--- Please Select ---</option>
                        <option value="PHE OSES"			>PHE OSES</option>
                        <option value="SPARE LOGISTIC"		>SPARE	LOGISTIC</option>
                        <option value="BROKEN"				>BROKEN</option>
                        <option value="SUPLIER SERVICE"		>SUPLIER SERVICE</option>
                        <option value="LOST"				>LOST</option>
                        <option value="UNKNOWN POSITION"	>UNKNOWN POSITION</option>
                        <option value="N/A"					>N/A</option>
                      </select>
                    </div>

                    <div class="form-group">
                      <input type="submit" value="SAVE" name="save" class="btn btn-primary">
                      <input type="reset" value="RESET" class="btn btn-danger">
                    </div>
                </form>
              </div> <!-- penutup class  data -->

    </div> <!-- penutup class container -->
            
    <!-- End Content -->

    <!-- Footer -->
    <!-- End Footer -->

    <!-- js & jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>