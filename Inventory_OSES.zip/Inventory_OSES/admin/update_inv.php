

<!DOCTYPE html>
<html lang="en">
<head>

    <?php
        // connection to database -> tables
        include "../support/connect.php";
        // notifikasi
        include "../support/alerts.php";

    ?>

    <?php
      $query = mysqli_query($mysqli, "SELECT 
      id, 
      serial_number, 
      id_radio, 
      type_radio, 
      model, 
      department,
      bu,
      locations,
      user,
      alias,
      statuss
      FROM inventory WHERE id = '".$_GET['id']."'");
      $data = mysqli_fetch_array($query);
    ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICT Information Management System</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="../icon.JPG">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.1/css/all.css" integrity="sha384-xxzQGERXS00kBmZW/6qxqJPyxW3UR0BPsL4c8ILaIWXva5kFi7TxkIIaMiKtqV1Q" crossorigin="anonymous">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
    <!-- css -->
    <style>
        body{
            font-family: 'Raleway', sans-serif;
            font-family: 'Roboto', sans-serif;
        }

        form{
          width:60%;  
        }

        @media only screen and (min-width:300px) and (max-width:600px){
          .sidebar{
            width:95%;
            margin:auto;
          }

          .data{
            padding-top:30px;
            margin:auto;
            width:95%;
          }

          form{
            width:100%;
          }
        }

    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="dashboard_admin.php">Communication Support</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="dashboard_admin.php"><i class="fas fa-home"></i> Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-edit"></i> Input Form
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="create_log.php"><i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="create_inv.php"> <i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="create_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-database"></i> Record Database
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="read_log.php"> <i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="read_inv.php"><i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="read_stopcard.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
                <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="summary.php"><i class="fas fa-chart-bar"></i> Summary Inventory Trunking</a>
                </div>
          </li>
        </ul>
        <a class="btn btn-primary" href="../support/logout.php" role="button">Logout <i class="fas fa-sign-out-alt"></i></a>
      </div>
    </nav>
          <!-- End Navbar -->
          
          <!-- Content -->

          <br><br><br>
          <div class="row">
            <!-- Sidebar -->
            <div class="col-sm-3 offset-sm-1" style=" text-align:justify;">
              <div class="sidebar">
              <div class="accordion" id="accordionExample">

                <!-- 1st card  -->
                <div class="card">
                  <div class="card-header" id="headingOne">
                    <h2 class="mb-0">
                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                      Next Development
                      </button>
                    </h2>
                  </div>
                  <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                    <div class="card-body">
                      <iframe width="350" height="300" src="https://www.youtube.com/embed/eIb0o2Ni8s0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                  </div>
                </div>

                <!-- 2nd card -->
                <div class="card">
                  <div class="card-header" id="headingTwo">
                    <h2 class="mb-0">
                      <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                      Next Development
                      </button>
                    </h2>
                  </div>
                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <div class="card-body">
                      Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                    </div>
                  </div>
                </div>

                <!-- 3rd card -->
                <div class="card">
                  <div class="card-header" id="headingThree">
                    <h2 class="mb-0">
                      <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                      Next Development
                      </button>
                    </h2>
                  </div>
                  <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div class="card-body">
                      Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                    </div>
                  </div>
                </div>

                </div> <!-- penutup accordion -->
              </div> <!-- penutup class sidebar -->
            </div> <!-- penutup class col-sm-3 offset-sm-1 / kolom pertama -->
            
            <!-- Data -->
            <br><br><br>
            <div class="col-sm-8">
              <div class="data">
                <h2>Edit Data Inventory Trunking</h2>
                <form id="form_input" method="post">
                      <?php  
                        if(isset($_POST['update']))
                        {
                          mysqli_query($mysqli, "UPDATE inventory SET 
                          serial_number 		= '".$_POST['serial_number']."', 
                          id_radio 			= '".$_POST['id_radio']."', 
                          type_radio 			= '".$_POST['type_radio']."',
                          model 				= '".$_POST['model']."' , 
                          department 			= '".$_POST['department']."',
                          bu 					= '".$_POST['bu']."',
                          locations 			= '".$_POST['locations']."',
                          user 				= '".$_POST['user']."',
                          alias 				= '".$_POST['alias']."',
                          statuss 			= '".$_POST['statuss']."' 
                          WHERE id = '".$_GET['id']."'");
                          writeMsg('update.sukses') ;

                          //Re-Load Data from DB
                          $query = mysqli_query($mysqli, "SELECT 
                          id, 
                          serial_number, 
                          id_radio, 
                          type_radio, 
                          model, 
                          department, 
                          bu,
                          locations,
                          user,
                          alias,
                          statuss
                          FROM inventory WHERE id = '".$_GET['id']."'");
                          $data = mysqli_fetch_array($query);
                          // $all = mysqli_fetch_assoc($query);
                        }
                      ?>
                    <!-- SERIAL NUMBER -->
                    <div class="form-group">
                        <label class="control-label" for="SN"><b>SERIAL NUMBER</b></label>
                        <input type="text" class="form-control" name="serial_number" id="serial_number"  value="<?php echo $data['serial_number']; ?>" required >
                    </div>

                    <!-- ID RADIO -->
                    <div class="form-group">
                        <label class="control-label" for="id_radio"><b>ID RADIO </b></label>
                        <input type="text" class="form-control" name="id_radio" id="id_radio" value="<?php echo $data['id_radio']; ?>" required>
                    </div>

                    <!-- TYPE RADIO -->
                    <div class="form-group">
                      <label class="control-label" for="TYPE_R"><b>Type Radio</b></label><br>
                      <?php $tipe = $data['type_radio'] ?>
                      <label><input type="radio" name="type_radio"  value="XIRP8668I"<?php echo ($tipe == 'XIRP8668I') ? "checked": "" ?>> XIRP8668I</label>
                      <label><input type="radio" name="type_radio"  value="XIRM8668i"<?php echo ($tipe == 'XIRM8668i') ? "checked": "" ?>> XIRM8668i</label>
                    </div>
                    
                    <!-- MODEL -->
                    <div class="form-group">
                    <?php $md = $data['model'] ?>
                      <label class="control-label" for="MOD"><b>Model</b></label> <br>
                      <label><input type="radio" name="model"  value="HT" 		<?php echo ($md == 'HT') ? "checked": "" ?>> HT</label>
                      <label><input type="radio" name="model"  value="DESKTOP" <?php echo ($md == 'DESKTOP') ? "checked": "" ?>> DESKTOP</label>
                    </div>

                    <!-- DEPARTMENT -->
                    <div class="form-group">
                    <?php $dept = $data['department'] ?>
                        <label class="control-label" for="DEPT"><b>DEPARTMENT</b></label>
                        <select class="form-control" name="department" id="department" value="<?php echo $data['department']; ?>">
                          <option>--- Please Select ---</option>
                        <option <?php echo ($dept == 'DRILLING') ? "selected": "" ?>>DRILLING</option>
                        <option <?php echo ($dept == 'HRSSS') ? "selected": "" ?>>HRSSS</option>
                        <option <?php echo ($dept == 'ICT') ? "selected": "" ?>>ICT</option>
                        <option <?php echo ($dept == 'LIFTTING & MARINE OPERATION') ? "selected": "" ?>>LIFTTING & MARINE OPERATION</option>
                        <option <?php echo ($dept == 'NFD & PGF') ? "selected": "" ?>>NFD & PGF</option>
                        <option <?php echo ($dept == 'PRODUCTION CBU') ? "selected": "" ?>>PRODUCTION CBU</option>
                        <option <?php echo ($dept == 'PRODUCTION NBU') ? "selected": "" ?>>PRODUCTION NBU</option>
                        <option <?php echo ($dept == 'PRODUCTION SBU') ? "selected": "" ?>>PRODUCTION SBU</option>
                        <option <?php echo ($dept == 'QHSE') ? "selected": "" ?>>QHSE</option>
                        <option <?php echo ($dept == 'N/A') ? "selected": "" ?>>N/A</option>
                      </select>
                    </div>

                    <!-- BU -->
                    <div class="form-group">
                    <?php $businesUnit = $data['bu']?>
                        <label class="control-label" for="BUS"><b>BUSINESS UNIT</b></label>
                        <select class="form-control" name="bu" id="BUS" value="<?php echo $data['bu']; ?>">
                          <option>--- Plese Select ---</option>
                          <option <?php echo ($businesUnit =='BARGE')? "selected" :""	?>>BARGE	</option>
                          <option <?php echo ($businesUnit =='BOAT')? "selected" :""	?>>BOAT	</option>
                          <option <?php echo ($businesUnit =='CENTRAL')? "selected" :""	?>>CENTRAL	</option>
                          <option <?php echo ($businesUnit =='CIPALA')? "selected" :""	?>>CIPALA	</option>
                          <option <?php echo ($businesUnit =='GMS')? "selected" :""	?>>GMS	</option>
                          <option <?php echo ($businesUnit =='NORTH')? "selected" :""	?>>NORTH	</option>
                          <option <?php echo ($businesUnit =='OFFICE ISEB')? "selected" :""	?>>OFFICE ISEB	</option>
                          <option <?php echo ($businesUnit =='OFFICE JASNIKOM')? "selected" :""	?>>OFFICE JASNIKOM	</option>
                          <option <?php echo ($businesUnit =='RIG')? "selected" :""	?>>RIG	</option>
                          <option <?php echo ($businesUnit =='SOUTH')? "selected" :""	?>>SOUTH	</option>
                          <option <?php echo ($businesUnit =='WAREHOUSE KJ4')? "selected" :""	?>>WAREHOUSE KJ4	</option>
                          <option <?php echo ($businesUnit =='N/A')? "selected" :""	?>>N/A	</option>
                        </select>
                      </div>

                    <!-- LOCATIONS -->
                    <div class="form-group">
                    <?php $loca = $data['locations']?> 
                        <label class="control-label" for="LOC"><b>LOCATION</b></label>
                        <select class="form-control" name="locations" id="locations" value="<?php echo $data['locations']; ?>">
                          <option>--- Please Select ---</option>
                          <option <?php echo ($loca =='AIDA')? "selected" :""	?>>AIDA	</option>
                          <option <?php echo ($loca =='ASTI A')? "selected" :""	?>>ASTI A	</option>
                          <option <?php echo ($loca =='ATTI')? "selected" :""	?>>ATTI	</option>
                          <option <?php echo ($loca =='BANUWATI')? "selected" :""	?>>BANUWATI	</option>
                          <option <?php echo ($loca =='BANUWATI A')? "selected" :""	?>>BANUWATI A	</option>
                          <option <?php echo ($loca =='BANUWATI K')? "selected" :""	?>>BANUWATI K	</option>
                          <option <?php echo ($loca =='BAYU CAKRAWALA')? "selected" :""	?>>BAYU CAKRAWALA	</option>
                          <option <?php echo ($loca =='CILEGON GMS')? "selected" :""	?>>CILEGON GMS	</option>
                          <option <?php echo ($loca =='CILEGON PCI')? "selected" :""	?>>CILEGON PCI	</option>
                          <option <?php echo ($loca =='CINTA A')? "selected" :""	?>>CINTA A	</option>
                          <option <?php echo ($loca =='CINTA B')? "selected" :""	?>>CINTA B	</option>
                          <option <?php echo ($loca =='CINTA C')? "selected" :""	?>>CINTA C	</option>
                          <option <?php echo ($loca =='CINTA D')? "selected" :""	?>>CINTA D	</option>
                          <option <?php echo ($loca =='CINTA E')? "selected" :""	?>>CINTA E	</option>
                          <option <?php echo ($loca =='CINTA F')? "selected" :""	?>>CINTA F	</option>
                          <option <?php echo ($loca =='CINTA G')? "selected" :""	?>>CINTA G	</option>
                          <option <?php echo ($loca =='CINTA H')? "selected" :""	?>>CINTA H	</option>
                          <option <?php echo ($loca =='CIPALA')? "selected" :""	?>>CIPALA	</option>
                          <option <?php echo ($loca =='CNOOC 114')? "selected" :""	?>>CNOOC 114	</option>
                          <option <?php echo ($loca =='COSL 221')? "selected" :""	?>>COSL 221	</option>
                          <option <?php echo ($loca =='COSL 222')? "selected" :""	?>>COSL 222	</option>
                          <option <?php echo ($loca =='COSL 223')? "selected" :""	?>>COSL 223	</option>
                          <option <?php echo ($loca =='COSL 225')? "selected" :""	?>>COSL 225	</option>
                          <option <?php echo ($loca =='CREST RUBY')? "selected" :""	?>>CREST RUBY	</option>
                          <option <?php echo ($loca =='ERA MERAH PUTIH')? "selected" :""	?>>ERA MERAH PUTIH	</option>
                          <option <?php echo ($loca =='ERMA')? "selected" :""	?>>ERMA	</option>
                          
                          <option <?php echo ($loca =='FARIDA A')? "selected" :""	?>>FARIDA A	</option>
                          <option <?php echo ($loca =='FARIDA B')? "selected" :""	?>>FARIDA B</option>
                          <option <?php echo ($loca =='FARIDA C')? "selected" :""	?>>FARIDA C	</option>
                          <option <?php echo ($loca =='FEDERAL II')? "selected" :""	?>>FEDERAL II	</option>
                          <option <?php echo ($loca =='GIAT JAYA')? "selected" :""	?>>GIAT JAYA	</option>
                          <option <?php echo ($loca =='GITA A')? "selected" :""	?>>GITA A	</option>
                          <option <?php echo ($loca =='HYSY 902')? "selected" :""	?>>HYSY 902	</option>
                          <option <?php echo ($loca =='INA PERMATA 1')? "selected" :""	?>>INA PERMATA 1	</option>
                          <option <?php echo ($loca =='INA PERMATA 2')? "selected" :""	?>>INA PERMATA 2	</option>
                          <option <?php echo ($loca =='INDRI A')? "selected" :""	?>>INDRI A	</option>
                          
                          <option <?php echo ($loca =='INTAN A')? "selected" :""	?>>INTAN A	</option>
                          <option <?php echo ($loca =='INTAN AC')? "selected" :""	?>>INTAN AC	</option>
                          <option <?php echo ($loca =='INTAN B')? "selected" :""	?>>INTAN B	</option>
                          <option <?php echo ($loca =='INTAN BPC')? "selected" :""	?>>INTAN BPC	</option>
                          <option <?php echo ($loca =='JASNIKOM OFFICE')? "selected" :""	?>>JASNIKOM OFFICE	</option>
                          <option <?php echo ($loca =='JENNY')? "selected" :""	?>>JENNY	</option>
                          <option <?php echo ($loca =='KALIJAPAT')? "selected" :""	?>>KALIJAPAT	</option>
                          <option <?php echo ($loca =='KARMILA A')? "selected" :""	?>>KARMILA A	</option>
                          <option <?php echo ($loca =='KARTINI A')? "selected" :""	?>>KARTINI A	</option>
                          <option <?php echo ($loca =='KITTY A')? "selected" :""	?>>KITTY A	</option>
                          <option <?php echo ($loca =='KRISNA ALPHA')? "selected" :""	?>>KRISNA ALPHA	</option>
                          
                          <option <?php echo ($loca =='KRISNA B')? "selected" :""	?>>KRISNA B	</option>
                          <option <?php echo ($loca =='KRISNA C')? "selected" :""	?>>KRISNA C	</option>
                          <option <?php echo ($loca =='KRISNA D')? "selected" :""	?>>KRISNA D	</option>
                          <option <?php echo ($loca =='KRISNA E')? "selected" :""	?>>KRISNA E	</option>
                          <option <?php echo ($loca =='KRISNA P')? "selected" :""	?>>KRISNA P	</option>
                          <option <?php echo ($loca =='LCT PERDANA HARAPAN IX')? "selected" :""	?>>LCT PERDANA HARAPAN IX	</option>
                          <option <?php echo ($loca =='LITA')? "selected" :""	?>>LITA	</option>
                          <option <?php echo ($loca =='LOGINDO BRAVEHEART')? "selected" :""	?>>LOGINDO BRAVEHEART	</option>
                          <option <?php echo ($loca =='LOGINDO RALIANCE')? "selected" :""	?>>LOGINDO RALIANCE	</option>
                          <option <?php echo ($loca =='LYDIA')? "selected" :""	?>>LYDIA	</option>
                          
                          <option <?php echo ($loca =='MAGELANG')? "selected" :""	?>>MAGELANG	</option>
                          <option <?php echo ($loca =='MEGAWATI 17')? "selected" :""	?>>MEGAWATI 17	</option>
                          <option <?php echo ($loca =='MEGAWATI 2')? "selected" :""	?>>MEGAWATI 2	</option>
                          <option <?php echo ($loca =='MILA A')? "selected" :""	?>>MILA A	</option>
                          <option <?php echo ($loca =='MITRA ANUGRAH 32')? "selected" :""	?>>MITRA ANUGRAH 32	</option>
                          <option <?php echo ($loca =='MITRA ANUGRAH 35')? "selected" :""	?>>MITRA ANUGRAH 35	</option>
                          <option <?php echo ($loca =='NEIA A')? "selected" :""	?>>NEIA A	</option>
                          <option <?php echo ($loca =='NEIA AC')? "selected" :""	?>>NEIA AC	</option>
                          <option <?php echo ($loca =='NMS ACCELERATE')? "selected" :""	?>>NMS ACCELERATE	</option>
                          <option <?php echo ($loca =='NMS ACCOMPLISH')? "selected" :""	?>>NMS ACCOMPLISH	</option>
                          
                          <option <?php echo ($loca =='NMS ACHIEVE')? "selected" :""	?>>NMS ACHIEVE	</option>
                          <option <?php echo ($loca =='NMS BRILIANCE')? "selected" :""	?>>NMS BRILIANCE	</option>
                          <option <?php echo ($loca =='NORA A')? "selected" :""	?>>NORA A	</option>
                          <option <?php echo ($loca =='NORTH WANDA ALFA')? "selected" :""	?>>NORTH WANDA ALFA	</option>
                          <option <?php echo ($loca =='NORTH WANDA B')? "selected" :""	?>>NORTH WANDA B	</option>
                          <option <?php echo ($loca =='OFFICE ISEB')? "selected" :""	?>>OFFICE ISEB	</option>
                          <option <?php echo ($loca =='PABELOKAN')? "selected" :""	?>>PABELOKAN	</option>
                          <option <?php echo ($loca =='PAN MARINE 6')? "selected" :""	?>>PAN MARINE 6	</option>
                          <option <?php echo ($loca =='PAN MARINE 8')? "selected" :""	?>>PAN MARINE 8	</option>
                          <option <?php echo ($loca =='PAN MARINE 18')? "selected" :""	?>>PAN MARINE 18	</option>
                          
                          <option <?php echo ($loca =='PAN MARINE 19')? "selected" :""	?>>PAN MARINE 19	</option>
                          <option <?php echo ($loca =='PATRA MARINE')? "selected" :""	?>>PATRA MARINE	</option>
                          <option <?php echo ($loca =='PET. EXCELSIOR')? "selected" :""	?>>PET. EXCELSIOR	</option>
                          <option <?php echo ($loca =='PET. SUPERIOR')? "selected" :""	?>>PET. SUPERIOR	</option>
                          <option <?php echo ($loca =='PRISAI')? "selected" :""	?>>PRISAI	</option>
                          <option <?php echo ($loca =='RAMA A')? "selected" :""	?>>RAMA A	</option>
                          <option <?php echo ($loca =='RAMA B')? "selected" :""	?>>RAMA B	</option>
                          <option <?php echo ($loca =='RAMA C')? "selected" :""	?>>RAMA C	</option>
                          <option <?php echo ($loca =='RAMA D')? "selected" :""	?>>RAMA D	</option>
                          <option <?php echo ($loca =='RAMA E')? "selected" :""	?>>RAMA E	</option>
                          
                          <option <?php echo ($loca =='RAMA F')? "selected" :""	?>>RAMA F	</option>
                          <option <?php echo ($loca =='RAMA G')? "selected" :""	?>>RAMA G	</option>
                          <option <?php echo ($loca =='RAMA H')? "selected" :""	?>>RAMA H	</option>
                          <option <?php echo ($loca =='RAMA I')? "selected" :""	?>>RAMA I	</option>
                          <option <?php echo ($loca =='RAMA P')? "selected" :""	?>>RAMA P	</option>
                          <option <?php echo ($loca =='RIG HL 6')? "selected" :""	?>>RIG HL 6	</option>
                          <option <?php echo ($loca =='RIG LISA')? "selected" :""	?>>RIG LISA	</option>
                          <option <?php echo ($loca =='SALATIGA')? "selected" :""	?>>SALATIGA	</option>
                          <option <?php echo ($loca =='SELATAN A')? "selected" :""	?>>SELATAN A	</option>
                          <option <?php echo ($loca =='SOUTH WANDA A')? "selected" :""	?>>SOUTH WANDA A	</option>
                           
                          <option <?php echo ($loca =='SOUTH ZELDA')? "selected" :""	?>>SOUTH ZELDA	</option>
                          <option <?php echo ($loca =='STAR ONIX')? "selected" :""	?>>STAR ONIX	</option>
                          <option <?php echo ($loca =='SUNDARI A')? "selected" :""	?>>SUNDARI A	</option>
                          <option <?php echo ($loca =='SUNDARI B')? "selected" :""	?>>SUNDARI B	</option>
                          <option <?php echo ($loca =='SURATMI')? "selected" :""	?>>SURATMI	</option>
                          <option <?php echo ($loca =='SURF MANDIRI')? "selected" :""	?>>SURF MANDIRI	</option>
                          <option <?php echo ($loca =='SWIBER RUBY')? "selected" :""	?>>SWIBER RUBY	</option>
                          <option <?php echo ($loca =='THERESIA')? "selected" :""	?>>THERESIA	</option>
                          <option <?php echo ($loca =='TITI A PCR')? "selected" :""	?>>TITI A PCR	</option>
                          <option <?php echo ($loca =='TRANSKO BALIHE')? "selected" :""	?>>TRANSKO BALIHE	</option>
                          
                          <option <?php echo ($loca =='TRANSKO CELEBES')? "selected" :""	?>>TRANSKO CELEBES	</option>
                          <option <?php echo ($loca =='TRITON JAWARA')? "selected" :""	?>>TRITON JAWARA	</option>
                          <option <?php echo ($loca =='VITA')? "selected" :""	?>>VITA	</option>
                          <option <?php echo ($loca =='WANDA A')? "selected" :""	?>>WANDA A	</option>
                          <option <?php echo ($loca =='WIDURI A')? "selected" :""	?>>WIDURI A	</option>
                          <option <?php echo ($loca =='WIDURI B')? "selected" :""	?>>WIDURI B	</option>
                          <option <?php echo ($loca =='WIDURI C')? "selected" :""	?>>WIDURI C	</option>
                          <option <?php echo ($loca =='WIDURI D')? "selected" :""	?>>WIDURI D	</option>
                          <option <?php echo ($loca =='WIDURI DC')? "selected" :""	?>>WIDURI DC	</option>
                          <option <?php echo ($loca =='WIDURI E')? "selected" :""	?>>WIDURI E	</option>
                          
                          <option <?php echo ($loca =='WIDURI F')? "selected" :""	?>>WIDURI F	</option>
                          <option <?php echo ($loca =='WIDURI G')? "selected" :""	?>>WIDURI G	</option>
                          <option <?php echo ($loca =='WIDURI H')? "selected" :""	?>>WIDURI H	</option>
                          <option <?php echo ($loca =='WIDURI PROCESS')? "selected" :""	?>>WIDURI PROCESS	</option>
                          <option <?php echo ($loca =='WINDRI')? "selected" :""	?>>WINDRI	</option>
                          <option <?php echo ($loca =='YANI A')? "selected" :""	?>>YANI A	</option>
                          <option <?php echo ($loca =='YVONE ALPHA')? "selected" :""	?>>YVONE ALPHA	</option>
                          <option <?php echo ($loca =='YVONE B')? "selected" :""	?>>YVONE B	</option>
                          <option <?php echo ($loca =='ZELDA P')? "selected" :""	?>>ZELDA P	</option>
                          <option <?php echo ($loca =='ZELDA B')? "selected" :""	?>>ZELDA B	</option>
                          
                          <option <?php echo ($loca =='ZELDA C')? "selected" :""	?>>ZELDA C	</option>
                          <option <?php echo ($loca =='ZELDA D')? "selected" :""	?>>ZELDA D	</option>
                          <option <?php echo ($loca =='ZELDA E')? "selected" :""	?>>ZELDA E	</option>
                          <option <?php echo ($loca =='ZELDA F')? "selected" :""	?>>ZELDA F	</option>
                          <option <?php echo ($loca =='ZELDA PC')? "selected" :""	?>>ZELDA PC	</option>
                          <option <?php echo ($loca =='N/A')? "selected" :""	?>>N/A	</option>
                      </select>
                    </div>


                    <!-- USER -->
                    <div class="form-group">
                        <label class="control-label" for="user"><b>USER</b></label>
                        <input type="text" class="form-control" name="user" id="user" value="<?php echo $data['user']; ?>">
                    </div>

                    <!-- ALIAS -->
                    <div class="form-group">
                        <label class="control-label" for="ALI"><b>ALIAS</b></label>
                        <input type="text" class="form-control" name="alias" id="alias" value="<?php echo $data['alias']; ?>">
                    </div>

                    <!-- STATUS -->
                    <div class="form-group">
                    <?php $statu = $data['statuss']?>
                        <label class="control-label" for="STS"><b>STATUS</b></label>
                        <select class="form-control" name="statuss" id="statuss" value="<?php echo $data['statuss']; ?>">
                          <option>--- Please Select ---</option>
                        <option <?php echo ($statu =='PHE OSES')? "selected" :""	?>>PHE OSES	</option>
                        <option <?php echo ($statu =='SPARE LOGISTIC')? "selected" :""	?>>SPARE LOGISTIC	</option>
                        <option <?php echo ($statu =='BROKEN')? "selected" :""	?>>BROKEN	</option>
                        <option <?php echo ($statu =='SUPLIER SERVICE')? "selected" :""	?>>SUPLIER SERVICE	</option>
                        <option <?php echo ($statu =='LOST')? "selected" :""	?>>LOST	</option>
                        <option <?php echo ($statu =='UNKNOWN POSITION')? "selected" :""	?>>UNKNOWN	POSITION</option>
                        <option <?php echo ($statu =='N/A')? "selected" :""	?>>N/A	</option>
                        </select>
                      </div>

                    <div class="form-group">
                      <input type="submit" value="UPDATE" name="update" class="btn btn-primary">
                      <a href="read_inv.php" class="btn btn-danger">CANCEL</a>
                    </div>
                </form>
              </div> <!-- penutup class data -->
            </div> <!-- penutup class col-sm-8 / kolom kedua -->
          </div> <!-- penutup class row -->
          
          
          <!-- End Content -->

    <!-- Footer -->
    <!-- End Footer -->

    <!-- js & jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>