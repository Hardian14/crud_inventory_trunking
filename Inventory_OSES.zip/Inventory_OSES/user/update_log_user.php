

<!DOCTYPE html>
<html lang="en">
<head>

    <?php
        // connection to database -> tables
        include "../support/connect.php";
        // notifikasi
        include "../support/alerts.php";

    ?>

    <?php
      $query = mysqli_query($mysqli, "SELECT 
      id, 
      serial_number, 
      statuss, 
      remarks, 
      pic, 
      dates,
      last
      FROM history WHERE id = '".$_GET['id']."'");
      $data2 = mysqli_fetch_array($query);

    ?>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICT Information Management System</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="../icon.JPG">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.1/css/all.css" integrity="sha384-xxzQGERXS00kBmZW/6qxqJPyxW3UR0BPsL4c8ILaIWXva5kFi7TxkIIaMiKtqV1Q" crossorigin="anonymous">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
    <!-- css -->
    <style>
        body{
            font-family: 'Raleway', sans-serif;
            font-family: 'Roboto', sans-serif;
        }

        form{
          width:50%;

        }

        @media only screen and (min-width:300px) and (max-width:600px){
          .sidebar{
            width:95%;
            margin:auto;
          }

          .data{
            padding-top:30px;
            margin:auto;
            width:95%;
          }

          form{
            width:100%;
          }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="dashboard_user.php">Communication Support</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="dashboard_user.php"><i class="fas fa-home"></i> Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-edit"></i> Input Form
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="create_log_user.php"><i class="fas fa-history"></i> History Log Trunking</a>
                
                <a class="dropdown-item" href="create_stopcard_user.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-database"></i> Record Database
            </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="read_log_user.php"> <i class="fas fa-history"></i> History Log Trunking</a>
                <a class="dropdown-item" href="read_inv_user.php"><i class="fas fa-warehouse"></i> Inventory Trunking</a>
                <a class="dropdown-item" href="read_stopcard_user.php"> <i class="fas fa-book-medical"></i> Stop Card</a>
                <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="summary_user.php"><i class="fas fa-chart-bar"></i> Summary Inventory Trunking</a>
                </div>
          </li>
        </ul>
        <a class="btn btn-primary" href="../support/logout.php" role="button">Logout <i class="fas fa-sign-out-alt"></i></a>
      </div>
    </nav>
          <!-- End Navbar -->
          
          <!-- Content -->

          <br><br><br>
          <div class="row">
            <!-- Sidebar -->
            <div class="col-sm-3 offset-sm-1" style=" text-align:justify;">
              <div class="sidebar">
                <div class="accordion" id="accordionExample">

                <!-- 1st card  -->
                <div class="card">
                  <div class="card-header" id="headingOne">
                    <h2 class="mb-0">
                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                      Next Development
                      </button>
                    </h2>
                  </div>
                  <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                    <div class="card-body">
                      Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                    </div>
                  </div>
                </div>

                <!-- 2nd card -->
                <div class="card">
                  <div class="card-header" id="headingTwo">
                    <h2 class="mb-0">
                      <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                      Next Development
                      </button>
                    </h2>
                  </div>
                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <div class="card-body">
                      Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                    </div>
                  </div>
                </div>

                <!-- 3rd card -->
                <div class="card">
                  <div class="card-header" id="headingThree">
                    <h2 class="mb-0">
                      <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                      Next Development
                      </button>
                    </h2>
                  </div>
                  <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div class="card-body">
                      Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                    </div>
                  </div>
                </div>

                </div> <!-- penutup accordion -->
              </div> <!-- penutup class sidebar -->
            </div> <!-- penutup class col-sm-3 offset-sm-1 / kolom pertama -->
            <!-- Data -->
            <div class="col-sm-8">
              <div class="data">
              <h2>Data Inventory Trunking</h2>
                <form id="form_input" method="POST">	
                  <?php  
                    if(isset($_POST['update']))
                    {
                      mysqli_query($mysqli, "UPDATE history SET 
                      serial_number 		= '".$_POST['serial_number']."', 
                      statuss 			= '".$_POST['statuss']."', 
                      remarks 			= '".$_POST['remarks']."',
                      pic 				= '".$_POST['pic']."' , 
                      dates	 			= '".$_POST['dates']."',
                      last	 			= '".$_POST['last']."'
                      
                      WHERE id = '".$_GET['id']."'");
                      writeMsg('update.sukses') ;

                      //Re-Load Data from DB
                      $query = mysqli_query($mysqli, "SELECT 
                      id, 
                      serial_number, 
                      statuss, 
                      remarks, 
                      pic, 
                      dates,
                      last
                      FROM history WHERE id = '".$_GET['id']."'");
                      $data2 = mysqli_fetch_array($query);
                      // $all = mysqli_fetch_assoc($query);
                    }
                  ?>

                      <!-- SERIAL NUMBER -->
                      <div class="form-group">
                          <label class="control-label" for="SN">SERIAL NUMBER</label>
                          <input type="text" class="form-control" name="serial_number" id="serial_number" value="<?php echo $data2['serial_number']; ?>" required>
                      </div>

                      <!-- STATUS -->
                      <div class="form-group">
                      <?php $sta = $data2['statuss']?>
                          <label class="control-label" for="STS"><b>STATUS</b></label>
                          <select class="form-control" name="statuss" id="statuss" value="<?php echo $data2['statuss']; ?>">
                            <option>--- Plese Select ---</option>
                          <option <?php echo ($sta =='BROKEN')					? "selected" :""	?>>BROKEN					</option>
                          <option <?php echo ($sta =='CHANGE AREA / LOCATION')	? "selected" :""	?>>CHANGE AREA / LOCATION	</option>
                          <option <?php echo ($sta =='CHANGE ID')				? "selected" :""	?>>CHANGE ID				</option>
                          <option <?php echo ($sta =='CHANGE USER')				? "selected" :""	?>>CHANGE USER				</option>
                          <option <?php echo ($sta =='LOST')						? "selected" :""	?>>LOST						</option>
                          <option <?php echo ($sta =='SENT TO JAKARTA')			? "selected" :""	?>>SENT TO JAKARTA			</option>
                          <option <?php echo ($sta =='UNKNOWN POSITION')			? "selected" :""	?>>UNKNOWN	POSITION		</option>
                          <option <?php echo ($sta =='OTHER')					? "selected" :""	?>>OTHER					</option>
                          </select>
                        </div>

                      <!-- REMARKS -->
                      <div class="form-group">
                          <label class="control-label" for="des"><b>REMARKS</b></label>
                          <textarea class="form-control" rows="10" name="remarks"><?php echo $data2['remarks'] ?></textarea>
                      </div>

                      <!-- PIC -->
                      <div class="form-group">
                        <label class="control-label" for="nama"><b>BY</b> </label>
                        <?php $by = $data2['pic'] ?>
                        <select class="form-control" name="pic">
                          <option>--- Silahkan Pilih ---</option>
                          <option <?php echo ($by == 'Dahrun Binan') ? "selected": "" ?>>Dahrun Binan</option>
                            <option <?php echo ($by == 'Dian Sulistyo') ? "selected": "" ?>>Dian Sulistyo</option>
                            <option <?php echo ($by == 'Edy Kurniawan') ? "selected": "" ?>>Edy Kurniawan</option>
                            <option <?php echo ($by == 'Hardian Affandy') ? "selected": "" ?>>Hardian Affandy</option>
                              <option <?php echo ($by == 'Husein Mawi') ? "selected": "" ?>>Husein Mawi</option>
                              <option <?php echo ($by == 'Irwandi') ? "selected": "" ?>>Irwandi</option>
                              <option <?php echo ($by == 'Iwan Yudi') ? "selected": "" ?>>Iwan Yudi</option>
                              <option <?php echo ($by == 'Kripton Wiryawan') ? "selected": "" ?>>Kripton Wiryawan</option>
                              <option <?php echo ($by == 'Marzuki') ? "selected": "" ?>>Marzuki</option>
                              <option <?php echo ($by == 'Ricky Faizal') ? "selected": "" ?>>Ricky Faizal</option>
                                <option <?php echo ($by == 'Roiman Marlin') ? "selected": "" ?>>Roiman Marlin</option>
                              <option <?php echo ($by == 'Sahidin') ? "selected": "" ?>>Sahidin</option>
                            <option <?php echo ($by == 'Samsi') ? "selected": "" ?>>Samsi</option>
                              <option <?php echo ($by == 'Saroji') ? "selected": "" ?>>Saroji</option>
                              <option <?php echo ($by == 'Suparman') ? "selected": "" ?>>Suparman</option>
                              <option <?php echo ($by == 'Syarief Hidayat') ? "selected": "" ?>>Syarief Hidayat</option>
                              <option <?php echo ($by == 'Widadi Haryoko') ? "selected": "" ?>>Widadi Haryoko</option>
                        </select>
                      </div>

                      <div class="form-group">
                        <label class="control-label" for="tgl"><b>DATE</b> </label>
                        <input type="date" name="dates" class="form-control"  value="<?php echo $data2['dates'] ?>" />
                      </div>

                        <!-- last update -->
                          <div class="form-group">
                          <?php $last = $data2['last']?>
                            <label class="control-label" for="latest"><b>LAST UPDATE</b></label>
                            <select class="form-control" name="last" id="last" value="<?php echo $data2['last']; ?>">
                              <option>--- Please Select ---</option>
                              <option <?php echo ($last =='OPEN')          ?"selected" :""	?>>OPEN</option>
                              <option <?php echo ($last =='PENDING')       ?"selected" :""	?>>PENDING</option>
                              <option <?php echo ($last =='IN PROGRESS')   ?"selected" :""	?>>IN PROGRESS</option>
                              <option <?php echo ($last =='CLOSED')        ?"selected" :""	?>>CLOSED</option>
                          </select>
                        </div>

                      <div class="form-group">
                      <input type="submit" value="UPDATE" name="update" class="btn btn-primary">
                      <a href="read_log_user.php" class="btn btn-danger">CANCEL</a>
                      </div>

                </form>
              </div> <!-- penutup class data -->
            </div> <!-- penutup class col-sm-8 / kolom kedua -->
          </div> <!-- penutup class row -->
          
          
          <!-- End Content -->

    <!-- Footer -->
    <!-- End Footer -->

    <!-- js & jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>