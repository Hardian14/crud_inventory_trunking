

<?php
/**
 * using mysqli_connect for database connection
 */

$databaseHost = 'sql212.epizy.com';
$databaseName = 'epiz_25680363_comm_db';
$databaseUsername = 'epiz_25680363';
$databasePassword = 'MZr8zRsK9Il';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

?>